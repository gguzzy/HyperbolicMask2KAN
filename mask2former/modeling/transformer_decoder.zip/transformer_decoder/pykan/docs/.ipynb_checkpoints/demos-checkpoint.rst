API Demos
---------

.. toctree::
   :maxdepth: 1

   API_demo/API_1_indexing.rst
   API_demo/API_2_plotting.rst
   API_demo/API_3_grid.rst
   API_demo/API_4_extract_activations.rst
   API_demo/API_5_initialization_hyperparameter.rst
   API_demo/API_6_training_hyperparameter.rst
   API_demo/API_7_pruning.rst
   API_demo/API_8_checkpoint.rst
   API_demo/API_9_video.rst
   API_demo/API_10_device.rst