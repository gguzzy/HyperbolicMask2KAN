kan package
===========

Submodules
----------

kan.KAN module
--------------

.. automodule:: kan.KAN
   :members:
   :undoc-members:
   :show-inheritance:

kan.KANLayer module
-------------------

.. automodule:: kan.KANLayer
   :members:
   :undoc-members:
   :show-inheritance:

kan.LBFGS module
----------------

.. automodule:: kan.LBFGS
   :members:
   :undoc-members:
   :show-inheritance:

kan.Symbolic\_KANLayer module
-----------------------------

.. automodule:: kan.Symbolic_KANLayer
   :members:
   :undoc-members:
   :show-inheritance:

kan.spline module
-----------------

.. automodule:: kan.spline
   :members:
   :undoc-members:
   :show-inheritance:

kan.utils module
----------------

.. automodule:: kan.utils
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: kan
   :members:
   :undoc-members:
   :show-inheritance:
